package com.zendesk.maxwell.producer;

public enum EncryptionMode {
	ENCRYPT_NONE,
	ENCRYPT_DATA,
	ENCRYPT_ALL
}
