package com.zendesk.maxwell.util;

public enum RunState { STOPPED, RUNNING, REQUEST_STOP }
