package com.zendesk.maxwell;

public class MaxwellInvalidFilterException extends Exception  {
	public MaxwellInvalidFilterException(String message) {
		super(message);
	}
}
